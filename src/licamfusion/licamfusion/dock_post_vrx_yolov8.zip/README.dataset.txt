# vrx > 2024-02-03 10:53am
https://universe.roboflow.com/njord-ymbo3/vrx-ajfer

Provided by a Roboflow user
License: CC BY 4.0

